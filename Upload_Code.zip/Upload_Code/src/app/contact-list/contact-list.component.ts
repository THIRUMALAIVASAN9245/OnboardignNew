import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';

@Component({
  selector: 'app-contact-list',
  templateUrl: './contact-list.component.html',
  styleUrls: ['./contact-list.component.css']
})
export class ContactListComponent implements OnInit {
  associatePlans: any[];
  contacts;
  selectedContact;
  constructor(public dataService: DataService) { }

  ngOnInit() {
    this.contacts = this.dataService.getContacts();
    this.associatePlans = [
      {
        Week: 1,
        Day: 2,
        KnowledgeTransferTitle: 3,
        ScheduledDate: new Date("02-02-2019"),
        CompletionDate: new Date("02-02-2019"),
        ProofType: 2
      },
      {
        Week: 1,
        Day: 2,
        KnowledgeTransferTitle: 3,
        ScheduledDate: new Date("02-02-2019"),
        CompletionDate: new Date("02-02-2019"),
        ProofType: 1
      },
      {
        Week: 1,
        Day: 2,
        KnowledgeTransferTitle: 3,
        ScheduledDate: new Date("02-02-2019"),
        CompletionDate: new Date("02-02-2019"),
        ProofType: 2
      },{
        Week: 1,
        Day: 2,
        KnowledgeTransferTitle: 3,
        ScheduledDate: new Date("02-02-2019"),
        CompletionDate: new Date("02-02-2019"),
        ProofType: 1
      },
      {
        Week: 1,
        Day: 2,
        KnowledgeTransferTitle: 3,
        ScheduledDate: new Date("02-02-2019"),
        CompletionDate: new Date("02-02-2019"),
        ProofType: 2
      },{
        Week: 1,
        Day: 2,
        KnowledgeTransferTitle: 3,
        ScheduledDate: new Date("02-02-2019"),
        CompletionDate: new Date("02-02-2019"),
        ProofType: 1
      },
      {
        Week: 1,
        Day: 2,
        KnowledgeTransferTitle: 3,
        ScheduledDate: new Date("02-02-2019"),
        CompletionDate: new Date("02-02-2019"),
        ProofType: 2
      },{
        Week: 1,
        Day: 2,
        KnowledgeTransferTitle: 3,
        ScheduledDate: new Date("02-02-2019"),
        CompletionDate: new Date("02-02-2019"),
        ProofType: 1
      },
      {
        Week: 1,
        Day: 2,
        KnowledgeTransferTitle: 3,
        ScheduledDate: new Date("02-02-2019"),
        CompletionDate: new Date("02-02-2019"),
        ProofType: 2
      },{
        Week: 1,
        Day: 2,
        KnowledgeTransferTitle: 3,
        ScheduledDate: new Date("02-02-2019"),
        CompletionDate: new Date("02-02-2019"),
        ProofType: 1
      },
      {
        Week: 1,
        Day: 2,
        KnowledgeTransferTitle: 3,
        ScheduledDate: new Date("02-02-2019"),
        CompletionDate: new Date("02-02-2019"),
        ProofType: 2
      },{
        Week: 1,
        Day: 2,
        KnowledgeTransferTitle: 3,
        ScheduledDate: new Date("02-02-2019"),
        CompletionDate: new Date("02-02-2019"),
        ProofType: 1
      },
      {
        Week: 1,
        Day: 2,
        KnowledgeTransferTitle: 3,
        ScheduledDate: new Date("02-02-2019"),
        CompletionDate: new Date("02-02-2019"),
        ProofType: 2
      }
    ]
  }
  public selectContact(contact) {
    this.selectedContact = contact;
  }
}
