﻿import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { IDashboard, Dashboard } from '../model/Dashboard';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import { HttpInterceptorService } from '../shared/httpInterceptor.service';
import { of } from 'rxjs/observable/of';

@Injectable()
export class DashboardService {
    private baseUrl: string

    constructor(public httpInterceptorService: HttpInterceptorService) {
        this.baseUrl = "Dashboard"
    }

    get(): Observable<IDashboard[]> {
        return of(this.getResonse());
        // return this.httpInterceptorService.get(this.baseUrl)
        //     .map((response: Response) => <IDashboard[]>response.json())
        //     .catch(this.handleError);
    }

    private handleError(error: Response) {
        console.error(error);
        return Observable.throw(error.json().error || 'Server error');
    }

    private getResonse(): IDashboard[] {

        const first = new Dashboard("1", "1", "1", "Project 1", "Team 1", "Role 1", 5, 7)
        const second = new Dashboard("2", "2", "2", "Project 2", "Team 2", "Role 2", 4, 6)
        const third = new Dashboard("3", "3", "3", "Project 3", "Team 3", "Role 3", 10, 9)

        return [first, second, third] as IDashboard[];
    }

}