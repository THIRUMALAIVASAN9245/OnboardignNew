﻿import { Injectable } from '@angular/core';
import { HttpInterceptorService } from '../shared/httpInterceptor.service';
import { Iteam } from '../model/team';
import { Observable } from 'rxjs/Observable';
import { Response, Request, Http } from '@angular/http';
import { of } from 'rxjs/observable/of';

@Injectable()
export class TeamService {

    private baseUrl: string;

    constructor(private httpInterceptorService: HttpInterceptorService) {
        this.baseUrl = "ProjectTeam";
    }

    getTeamList(projectId: string): Observable<Iteam[]> {
        return of(this.getResonse());
    }

    private handleError(error: Response) {
        return Observable.throw(error.json().error || "Server Error");
    }

    private getResonse(): Iteam[] {

        const first = { Id: "1", Name: "Role1", Code: "Code 1" };
        const second = { Id: "2", Name: "Role2", Code: "Code 1" };
        const third = { Id: "3", Name: "Role3", Code: "Code 1" };

        return [first, second, third] as Iteam[];
    }
}