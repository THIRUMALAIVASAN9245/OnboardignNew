﻿import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { IProject, Project } from '../model/project'
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import { HttpInterceptorService } from '../shared/httpInterceptor.service';
import { of } from 'rxjs/observable/of';

@Injectable()
export class ProjectService {
    private baseUrl:string

    constructor(private httpInterceptorService: HttpInterceptorService) {
        this.baseUrl = "Project"
    }

    get(): Observable<IProject[]> {
        return of(this.getResonse());
    }

    private handleError(error: Response) {
        console.error(error);
        return Observable.throw(error.json().error || 'Server error');
    }

    private getResonse(): IProject[] {

        const first = new Project("1","CODE1","Project 1");
        const second = new Project("1","CODE1","Project 1");
        const third = new Project("1","CODE1","Project 1");

        return [first, second, third] as IProject[];
    }
}