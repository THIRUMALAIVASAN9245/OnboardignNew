﻿import { Injectable } from "@angular/core";
import { Http, Response, Headers, RequestOptions } from "@angular/http";
import { Observable } from 'rxjs/Observable';
import { IUserRole } from '../model/userRole';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import { HttpInterceptorService } from '../shared/httpInterceptor.service';
import { environment } from '../../environments/environment.prod';
import { of } from "rxjs/observable/of";


@Injectable()
export class UserRoleService {
    private baseUrl: string;
    constructor(public httpInterceptorService: HttpInterceptorService) {
        this.baseUrl = "UserRole";
    }
    get(): Observable<IUserRole[]> {
        return of(this.getResonse());
    }
    private handleError(error: Response) {
        console.error(error);
        return Observable.throw(error.json().error || 'Server error');
    }

    private getResonse(): IUserRole[] {

        const first = {UserRoleId: "1",Role: "Role1",RoleDescription: "Project 1"};
        const second = {UserRoleId: "2",Role: "Role2",RoleDescription: "Project 1"};
        const third = {UserRoleId: "3",Role: "Role3",RoleDescription: "Project 1"};

        return [first, second, third] as IUserRole[];
    }

}