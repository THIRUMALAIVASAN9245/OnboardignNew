﻿import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { IMode, Mode } from '../model/mode'
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import { HttpInterceptorService } from '../shared/httpInterceptor.service';
import { of } from 'rxjs/observable/of';

@Injectable()
export class ModeService {
    private baseUrl:string

    constructor(public httpInterceptorService: HttpInterceptorService) {
        this.baseUrl = "Mode"
    }

    get(): Observable<IMode[]> {
        return of(this.getResonse());
    }

    private handleError(error: Response) {
        console.error(error);
        return Observable.throw(error.json().error || 'Server error');
    }

    private getResonse(): IMode[] {

        const first = new Mode("1","CODE1","Project 1");
        const second = new Mode("1","CODE1","Project 1");
        const third = new Mode("1","CODE1","Project 1");

        return [first, second, third] as IMode[];
    }
}