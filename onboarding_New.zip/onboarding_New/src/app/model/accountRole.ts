﻿export interface IAccountRole {
    Id: string,
    Code: string,
    Name: string
}
