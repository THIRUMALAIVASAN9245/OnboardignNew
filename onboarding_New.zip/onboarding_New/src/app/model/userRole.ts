﻿export interface IUserRole {
    
    UserRoleId: string,   
    Role: string,
    RoleDescription: string
}