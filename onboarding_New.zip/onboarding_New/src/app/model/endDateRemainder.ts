import { AllocationDetails } from "./allocation-details";

export class EndDateRemainder{
    rowData:AllocationDetails;
    constructor(rowData:any){
        this.rowData=rowData;
    }
}