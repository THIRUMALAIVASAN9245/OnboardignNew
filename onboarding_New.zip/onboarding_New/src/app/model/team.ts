﻿export interface Iteam {
    Id: string,
    Name: string,
    Code: string
}