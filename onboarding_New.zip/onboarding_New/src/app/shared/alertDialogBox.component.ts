import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { Router } from '@angular/router';
import { Data } from './Data';

@Component({
  selector: 'app-alert-dialog-box',
  templateUrl: './alertDialogBox.component.html'
})
export class AlertDialogBoxComponent implements OnInit {

  public title: string;
  public message: any;
  public titleAlign?: string;
  public messageAlign?: string;
  public btnOkText?: string;
  constructor(public dialogRef: MatDialogRef<AlertDialogBoxComponent>,private router: Router,private mydata:Data) { }

  public okButton() {
    this.dialogRef.close(true);
  }
  public isString(val){
    
    if(typeof val === 'string'){

    return true;

    }
    else 
    return false;
  }
  updateRecord(row){
    this.mydata.updateData = row;
    this.router.navigateByUrl('/UpdateRecord');
    this.dialogRef.close(true);
  }
  ngOnInit() {
  }

}
