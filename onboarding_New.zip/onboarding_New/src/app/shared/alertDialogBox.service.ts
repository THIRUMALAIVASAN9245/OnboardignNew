import { Observable } from 'rxjs/Rx';
import { AlertDialogBoxComponent } from './alertDialogBox.component';
import { MatDialogRef, MatDialog, MatDialogConfig } from '@angular/material';
import { Injectable, ViewContainerRef } from '@angular/core';
import { Router } from '@angular/router';


@Injectable()
export class AlertDialogBoxService {
    constructor(private dialog: MatDialog,public router:Router) { }

    public alertDialogBox(title: string, message: any, disableClose: boolean = false, titleAlign: string = 'center',
        messageAlign: string = 'center', btnOkText: string = 'Ok',redirectUrl?:string){

        let dialogRef: MatDialogRef<AlertDialogBoxComponent>;
        let config = new MatDialogConfig();
        config.disableClose = disableClose;
        dialogRef = this.dialog.open(AlertDialogBoxComponent, config);
        dialogRef.componentInstance.title = title;
        dialogRef.componentInstance.message = message;
        dialogRef.componentInstance.titleAlign = titleAlign;
        dialogRef.componentInstance.messageAlign = messageAlign;
        dialogRef.componentInstance.btnOkText = btnOkText;
        dialogRef.afterClosed().subscribe(result => {
            if(redirectUrl!=null)
            this.router.navigateByUrl(redirectUrl);
        });
    }


}