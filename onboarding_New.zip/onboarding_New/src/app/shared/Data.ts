import { Injectable } from '@angular/core';
import { AllocationDetails } from '../model/allocation-details';
@Injectable()
export class Data {
    public status = ['Active', 'De-Activate', 'Temporary', 'Long Leave'];
    public pageCountOptions=[5, 10, 20];
    public marginValue=35;
    public updateData: AllocationDetails = null;
    
    public constructor() {
     }
}