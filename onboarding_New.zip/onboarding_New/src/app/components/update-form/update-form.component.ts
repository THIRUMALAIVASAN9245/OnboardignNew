import { Component, OnInit } from '@angular/core';
import { AllocationDetails } from '../../model/allocation-details';
import { HttpClient } from '@angular/common/http';
import { Data } from "../../shared/Data";
import { environment } from '../../../environments/environment.prod';
import { AlertDialogBoxService } from '../../shared/alertDialogBox.service';
@Component({
  selector: 'app-update-form',
  templateUrl: './update-form.component.html',
  styleUrls: ['./update-form.component.css']
})
export class UpdateFormComponent implements OnInit {
  formData1: AllocationDetails;
  textBoxDisabled: boolean;
  isReadOnly: boolean = true;
  grade = [];
  programme = [];
  esaproject = [];
  ratecardrole = [];
  portfolio=[];
  department=[];
  ApiPath = environment.apiUrl;
  Status = [];
  constructor(private httpService: HttpClient, private mydata: Data, private alertDialogBoxService: AlertDialogBoxService) {
    this.formData1 = {
      CognizantID: "0",
      CognizantName: '',
      CognizantGrade: 0,
      SkillSets: '',
      Location: '',
      CtsLineMgr: '',
      ESAPrjName: 0,
      BillNBill: false,
      RsrcAllocEndDt: new Date(),
      VIEndDtOnshore: new Date(),
      VIType: '',
      VIExtPosblByndEnddt: false,
      VIHwLngCanExt: '',
      VIExtPosbleFrmUK: false,
      Margin:0,
      ResourceName: '',
      RateCardRole: 0,
      RateCardDayRate: '',
      OnOff2017: false,
      ProjectProgramme: 0,
      Portfolio: 0,
      OldSOW: '',
      NewSOWEnddate: null,
      NewSOW: '',
      Billable: false,
      RLGAccountYN: false,
      RLGStaffID: 0,
      CTSEL: '',
      RLGID: 123,
      RLGEmail: '',
      RLGJoinDate: new Date(),
      RLGLeavingDate: new Date(),
      RLGRprtMgr: '',
      AssetNoOnshore: '',
      VMNoOffshore: '',
      Comments: '',
      PrimarySkill: '',
      Department:0,
      Status: ''
    }
  }

  ngOnInit() {
    this.Status=this.mydata.status;
    if (this.mydata.updateData != null) {
      this.formData1 = this.mydata.updateData;
      this.textBoxDisabled = !this.mydata.updateData.RLGAccountYN;
    }

    this.httpService.get(this.ApiPath + 'ResourceMasterReference').subscribe((response) => {
      this.grade = response["CognizantGrade"];
      this.programme = response["ProjectProgramme"];
      this.ratecardrole = response["RateCardRole"];
      this.esaproject = response["ESAProjectName"];
      this.department= response["DepartmentName"];
      this.portfolio= response["PortfolioName"];
    });
  }
  toggle() {
    this.textBoxDisabled = !this.textBoxDisabled;
    if (this.textBoxDisabled == true) {
      this.formData1.RLGStaffID = 0;
      this.formData1.CTSEL = '';
      this.formData1.RLGID = 0;
      this.formData1.RLGEmail = '';
      this.formData1.RLGJoinDate = new Date();
      this.formData1.RLGLeavingDate = new Date();
      this.formData1.RLGRprtMgr = '';
      this.formData1.AssetNoOnshore = '';
      this.formData1.VMNoOffshore = '';
      this.formData1.Comments = '';
      this.formData1.PrimarySkill = '';
      this.formData1.Status = '';
    }
  }

  onUpdate() {
    this.httpService.put(this.ApiPath + 'ResourceValues', this.formData1).subscribe(() => {
      this.alertDialogBoxService.alertDialogBox("Update Details", "success", true, null, null, "Ok", '/resourceDetail');
    });
  }
}
