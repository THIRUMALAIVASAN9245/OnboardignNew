import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Data } from '../../shared/Data';
import { environment } from '../../../environments/environment.prod';
import { AllocationDetails } from '../../model/allocation-details';
import { AlertDialogBoxService } from '../../shared/alertDialogBox.service';

@Component({
  selector: 'app-update-details',
  templateUrl: './update-details.component.html',
  styleUrls: ['./update-details.component.css']
})
export class UpdateDetailsComponent implements OnInit {

  UpdateDetails: AllocationDetails;
  textBoxDisabled = true;
  isReadOnly: boolean = true;
  grade = [];
  programme = [];
  esaproject = [];
  ratecardrole = [];
  portfolio=[];
  department=[];
  ApiPath = environment.apiUrl;
  status = [];
  datacheck: Boolean = false;
  constructor(private httpService: HttpClient, private mydata: Data, private alertDialogBoxService: AlertDialogBoxService) {

  }
  formData: AllocationDetails;
  ngOnInit() {
    this.UpdateDetails = this.mydata.updateData;
    this.status=this.mydata.status;
    
    this.formData = {
      CognizantID: '',
      CognizantName: '',
      CognizantGrade: 0,
      SkillSets: '',
      Location: '',
      CtsLineMgr: '',
      ESAPrjName: 0,
      BillNBill: false,
      RsrcAllocEndDt: new Date("1900-01-01"),
      VIEndDtOnshore: new Date("1900-01-01"),
      VIType: '',
      VIExtPosblByndEnddt: false,
      VIHwLngCanExt: '',
      VIExtPosbleFrmUK: false,
      Margin:0,
      ResourceName: '',
      RateCardRole: 0,
      RateCardDayRate: '',
      OnOff2017: false,
      ProjectProgramme: 0,
      Portfolio: 0,
      OldSOW: '',
      NewSOWEnddate: new Date("1900-01-01"),
      NewSOW: '',
      Billable: false,
      RLGAccountYN: false,
      RLGStaffID: 0,
      CTSEL: '',
      RLGID: 0,
      RLGEmail: '',
      RLGJoinDate: new Date("1900-01-01"),
      RLGLeavingDate: new Date("1900-01-01"),
      RLGRprtMgr: '',
      AssetNoOnshore: '',
      VMNoOffshore: '',
      Comments: '',
      PrimarySkill: '',
      Department:0,
      Status: ''
    }

    this.httpService.get(this.ApiPath + 'ResourceMasterReference').subscribe((response) => {
      this.grade = response["CognizantGrade"];
      this.programme = response["ProjectProgramme"];
      this.ratecardrole = response["RateCardRole"];
      this.esaproject = response["ESAProjectName"];
      this.department= response["DepartmentName"];
      this.portfolio= response["PortfolioName"];
      
    });
  }

  toggle() {
    this.textBoxDisabled = !this.textBoxDisabled;
  }

  onSubmit() {
    if (this.formData.CognizantID != '' && this.formData.CognizantName != '' && this.formData.ResourceName != '') {
      this.httpService.post(this.ApiPath + 'ResourceMasterReference', this.formData)
        .subscribe(response => {
          this.alertDialogBoxService.alertDialogBox("New Record", response.toString(), true, null, null, "Ok", '/resourceDetail');
        });
    }
  }

}
