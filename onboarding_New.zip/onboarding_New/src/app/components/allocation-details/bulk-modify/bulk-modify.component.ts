import { Component, OnInit } from '@angular/core';
import { BulkModifyService } from '../../../service/bulkModify.service';
import { IProjectProgram, IUpdateProjectProgram, UpdateProjectProgram } from '../../../model/projectprogram';
import { AlertService } from '../../../shared/alert.service';
import { isNullOrUndefined } from 'util';
import { AlertDialogBoxService } from '../../../shared/alertDialogBox.service';

@Component({
  selector: 'app-bulk-modify',
  templateUrl: './bulk-modify.component.html',
  styleUrls: ['./bulk-modify.component.css']
})
export class BulkModifyComponent {
  currentProject: number;
  projectsList: IProjectProgram[];
  modifiedDate: Date;
  formdata: IUpdateProjectProgram;
  constructor(private bulkModifyService: BulkModifyService, private alertService: AlertService,private alertDialogBoxService:AlertDialogBoxService) {
    bulkModifyService.getProjects().subscribe(modal => {
      this.projectsList = modal["ProjectProgramme"];
    });
  }
  onModify() {
    if (!isNullOrUndefined(this.currentProject)) {
      this.formdata = new UpdateProjectProgram(this.currentProject, this.modifiedDate);
      this.bulkModifyService.put(this.formdata).subscribe(modal => {
        this.alertDialogBoxService.alertDialogBox("Project End Date Modification", "Project Details Updation " + modal, true, null, null, "Ok", '/resourceDetail');
      });
    }
    else{
      this.alertService.error("Please select correct project");
      this.modifiedDate=null;
    }
  }

}
