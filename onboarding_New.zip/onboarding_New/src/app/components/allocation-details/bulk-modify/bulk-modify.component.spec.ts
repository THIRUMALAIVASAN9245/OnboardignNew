import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BulkModifyComponent } from './bulk-modify.component';

describe('BulkModifyComponent', () => {
  let component: BulkModifyComponent;
  let fixture: ComponentFixture<BulkModifyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BulkModifyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BulkModifyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
