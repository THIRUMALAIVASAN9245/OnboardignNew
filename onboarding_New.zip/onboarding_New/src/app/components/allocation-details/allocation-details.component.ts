import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import * as XLSX from 'xlsx';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Data } from "../../shared/Data";
import { environment } from '../../../environments/environment.prod';
import { AlertDialogBoxService } from '../../shared/alertDialogBox.service';
import { ExcelFileExportService } from '../../service/excelFileExport.service';
import { EndDateRemainder } from '../../model/endDateRemainder';
import { UserRoleService } from '../../service/userRole.service';

@Component({
  selector: 'app-allocation-details',
  templateUrl: './allocation-details.component.html',
  styleUrls: ['./allocation-details.component.css']
})
export class AllocationDetailsComponent implements OnInit {
  MyList: any = [];
  Result: any;
  FullData = {};
  selectedFile: File;
  BackupList: any;
  grade = [];
  programme = [];
  esaproject = [];
  ratecardrole = [];
  portfolio=[];
  department=[];
  SearchString: string = "";
  page: number = 1;
  totalitems = 10;
  sortcheck: boolean = true;
  selectedCount: number = 5;
  pageCountOptions = [];
  deactivatedView: boolean = false;
  isAdmin: boolean = false;
  isResourceMasterAdmin: boolean = false;
  ApiPath = environment.apiUrl;
  a: boolean = false;
  sortKey: string = 'NewSOW';
  file: any;
  @ViewChild('TABLE') table: ElementRef;
  constructor(private httpService: HttpClient, private router: Router, private mydata: Data, private alertDialogBoxService: AlertDialogBoxService, private userRoleService: UserRoleService, private excelFileExportService: ExcelFileExportService) {
  }

  ngOnInit() {
    
    this.userRoleService.get()
      .subscribe(model => {
        this.isAdmin = model.filter(i => i.Role == "Admin").length == 1;
        this.isResourceMasterAdmin = model.filter(i => i.Role == "ResourceMasterAdmin").length == 1;
      });

    this.pageCountOptions = this.mydata.pageCountOptions;
    this.refreshData();
    this.httpService.get(this.ApiPath + 'ResourceValues').subscribe(
      data => {
        this.MyList = data as string[];
        if (this.deactivatedView) {
          this.MyList.forEach(element => {
            if (element.Status != 'De-Activate')
              this.MyList = this.MyList.filter(item => item !== element);
          });
        }
        else {
          this.MyList.forEach(element => {
            if (element.Status == 'De-Activate')
              this.MyList = this.MyList.filter(item => item !== element);
          });
        }

        this.BackupList = this.MyList;
        this.endDateRemainder();
      });
  }

  endDateRemainder() {
    let todayDate = new Date();
    let remainderList = new Array<any>();
    this.MyList.forEach(element => {
      let allocationEndDate = new Date(element.RsrcAllocEndDt);
      var diff = Math.floor((Date.UTC(todayDate.getFullYear(), todayDate.getMonth(), todayDate.getDate()) - Date.UTC(allocationEndDate.getFullYear(), allocationEndDate.getMonth(), allocationEndDate.getDate())) / (1000 * 60 * 60 * 24));
      if (diff >= -28 && diff <= 0) {
        remainderList.push(new EndDateRemainder(element));
      }
    });
    if (remainderList.length != 0)
      this.alertDialogBoxService.alertDialogBox("Allocation End Date Remainder", remainderList, true, null, null, "Ok", null);
  }

  showOrHideInActiveResources() {
    if (this.deactivatedView == false) {
      this.deactivatedView = true;
      document.getElementById("showOrHideInActiveResources").innerHTML = "Hide InActive Resources"
    }
    else {
      this.deactivatedView = false;
      document.getElementById("showOrHideInActiveResources").innerHTML = "Show InActive Resources"
    }
    this.ngOnInit();
  }

  refreshData() {
    this.httpService.get(this.ApiPath + 'ResourceMasterReference').subscribe((response) => {
      this.grade = response["CognizantGrade"];
      this.programme = response["ProjectProgramme"];
      this.ratecardrole = response["RateCardRole"];
      this.esaproject = response["ESAProjectName"];
      this.department= response["DepartmentName"];
      this.portfolio= response["PortfolioName"];
    });
  }

  sort(key: any) {
    let currentSortItem: any;
    let nextSortItem: any;
    if (this.sortcheck) {
      this.sortcheck = false;
      return this.MyList.sort(function (firstList: any, secondList: any) {
        currentSortItem = firstList[key];
        nextSortItem = secondList[key];
        return ((currentSortItem < nextSortItem) ? -1 : ((currentSortItem > nextSortItem) ? 1 : 0));
      });
    }
    else {
      this.sortcheck = true;
      return this.MyList.sort(function (firstList: any, secondList: any) {
        currentSortItem = firstList[key];
        nextSortItem = secondList[key];
        return ((currentSortItem > nextSortItem) ? -1 : ((currentSortItem < nextSortItem) ? 1 : 0));
      });
    }
  }

  UploadFile(event) {
    this.selectedFile = event.target.files[0];
    const uploadData = new FormData();
    uploadData.append('myFile', this.selectedFile, this.selectedFile.name);
    this.httpService.post(this.ApiPath + 'ResourceValues', uploadData).subscribe((response) => {
      this.Result = response;
    });

    this.refreshData();
  }

  viewRecord(Data) {
    this.FullData = Data;
  }

  updateRecord(UData) {
    this.mydata.updateData = UData;
    this.router.navigateByUrl('/UpdateRecord');
  }

  downloadFile() {
    let link = document.createElement("a");
    link.download = "Template";
    link.href = "./assets/ResourceListTemplate.xlsx";
    link.click();
  }

  resetTable() {
    let clearform = document.getElementById("myreset");
    clearform.click();
    this.Result = null;
  }

  resetinput(form: NgForm) {
    form.resetForm();
  }

  SubmitData() {
    this.httpService.post(this.ApiPath + 'ResourceMaster', null).subscribe((response) => {
      alert(response);
      this.resetTable();
    });
  }

  ExportTOExcel() {
    console.log("export");
    const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(this.table.nativeElement);
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    this.file = XLSX.writeFile(wb, 'ResourceMasterSheet.xlsx');
    // this.excelFileExportService.post(wb).subscribe(modal => {
    //   });
  }

  SearchFunction() {
    var input: any;
    input = document.getElementById("myInput");
    this.SearchString = input.value.toUpperCase().trim();
    if (this.SearchString == "") {
      this.MyList = this.BackupList;
    }
    else {
      let param = new HttpParams().set('SearchString', this.SearchString).set('FilterKey', this.sortKey);
      this.httpService.get(this.ApiPath + 'ResourceMasterSearch', { params: param }).subscribe(response => {
        this.MyList = response;
      });
    }
  }
}
