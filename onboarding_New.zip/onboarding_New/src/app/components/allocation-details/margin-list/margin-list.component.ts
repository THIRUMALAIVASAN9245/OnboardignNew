import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { environment } from '../../../../environments/environment.prod';
import { Data } from '../../../shared/Data';

@Component({
  selector: 'app-margin-list',
  templateUrl: './margin-list.component.html',
  styleUrls: ['./margin-list.component.css']
})
export class MarginListComponent implements OnInit {
  MarginList=[];
  MarginData=[];
  marginValue:number;
  grade = [];
  programme = [];
  esaproject = [];
  ratecardrole = [];
  portfolio=[];
  department=[];
  ApiPath = environment.apiUrl;
  constructor(private httpService: HttpClient,private data:Data ,private router: Router) { }

  ngOnInit() {
    this.marginValue=this.data.marginValue;
    this.httpService.get(this.ApiPath + 'ResourceValues').subscribe(
      data => {
        this.MarginList = data as string[];
        this.MarginList.forEach(element => {
          if (element.Margin <=this.marginValue)
            this.MarginData.push(element);
        });
      });
      this.httpService.get(this.ApiPath + 'ResourceMasterReference').subscribe((response) => {
        this.grade = response["CognizantGrade"];
        this.programme = response["ProjectProgramme"];
        this.ratecardrole = response["RateCardRole"];
        this.esaproject = response["ESAProjectName"];
        this.department= response["DepartmentName"];
        this.portfolio= response["PortfolioName"];
      });
  }
}
