export const environment = {
  production: true,
  apiUrl: "http://10.232.198.50:8088/ResourceMasterAPI/api/"
};